import React from 'react'
import {Login} from './Components/Login'
import {Logout} from './Components/Logout'
import {useSelector} from 'react-redux'
import {selectUser} from './features/userSlice'
import './App.css'
// import { createStore } from 'redux'
// import {reducer} from './app/store'

// const store = createStore(reducer)
export const App = () => {
  const user = useSelector(selectUser)

  return (
    <div>
      {user ? <Logout/> : <Login/>}
    </div>
   
  );
}

