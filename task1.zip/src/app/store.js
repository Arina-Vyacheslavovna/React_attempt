import {configureStore} from '@reduxjs/toolkit';
import {userReducer} from '../features/userSlice';
import { combineReducers, compose } from 'redux'
import { createStore } from 'redux';
import {productsReducer} from './reducer'

const composeEnhancers =
  typeof window === 'object' &&
  (window).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ &&
  process.env.NODE_ENV === 'development'
    ? (window).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({})
    : compose

export const store = createStore(combineReducers({
    products: productsReducer,
    user: userReducer
  }),composeEnhancers);

// configureStore({
//     reducer: {
//         user: useReducer,
//     },
// });

// export const store = combineReducers ({
//     productsReducer,
//     user: useReducer
//   })